<?php get_header(); ?>

<div class="row">
<div class="container">
<div id="wrap-container" class="bread-bg">
    <div id="container" class="bread-tittle"> 
        <h3 class="welcome-text"><?php the_title(); ?></h3> 
    </div>
</div>

<!--welcome home area-->
<div id="wrap-container" class="Welcome-home" >
<div id="container" class="contain-bg"> 

<div class="wrapper grid2">
<?php while(have_posts()): the_post()?>	
		
		<div class="col col-welcome-home">
		   <div id="featured-images" class="image-left">
	                    <?php if ( has_post_thumbnail() ) {
							$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
							$imageurl = $thumb['0'];
							?>  
							<img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo $imageurl; ?>&amp;w=227&amp;h=168&amp;zc=0">
							<?php } else { ?>
	                    <img src="" style="display:none" />
	                    <style>.the-shadow{display:none;}</style>
	                    <?php } ?>
                    	</a>
                    </div> <!-- featured-image -->
			<?php echo the_content(); ?>
      
	  <?php endwhile;?>
      <?php 
      $pages = array('adult-orthodontics','cosmetic-dentistry','emergency-services-for-toothaches-and-other-pain','gum-disease-therapy','metal-free-crowns','porcelain-veneers','short-term-orthodontics',
	  'teeth-replacement-full-dentures-partial-dentures-mini-and-standard-implants','relieving-dental-anxiety','invisalign','snoring-and-sleep-apnea','tmj-solutions','tooth-extractions','oral-appliances',
	  'mini-and-standard-dental-implants','teeth-whitening','i-cant-eat-the-food-i-love','dental-check-ups-and-cleanings','root-canals');
      if( is_page($pages)):
      ?>
      <style type="text/css">
      #featured-images{display: none;}
      </style>
     <?php 
     endif;
     ?>
	  <span class="edits"><?php edit_post_link('Edit this post'); ?> </span> 
		</div>
		
		<!--sidebar-->
		<!--?php include (TEMPLATEPATH.'/sidebar.php'); ?-->	
		<!--sidebar-->
		

</div><!--wrapper grid2-->

</div><!--end-containerbg-->
</div> <!--end wrap-container-->
<!--welcome home area-->
</div>
</div>

<?php get_footer(); ?>