<?php get_header();
/*
Template Name: Single Page
*/
 ?>


<div class="row">
<div class="container">

<div id="wrap-container" class="bread-bg"><div id="container" class="bread-tittle"> <h3 class="welcome-text"><?php the_title(); ?> </h3> 
</div></div>
<!--welcome home area-->
<div id="wrap-container" class="Welcome-home" >
<div id="container" class="contain-bg"> 

<div class="wrapper">
<?php while(have_posts()): the_post()?>	
		
		<div class="col col-welcome-home">
			
		<div id="featured-images" class="image-left">
	                    <?php if ( has_post_thumbnail() ) {
							$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
							$imageurl = $thumb['0'];
							?>  
							<img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo $imageurl; ?>&amp;w=210&amp;h=160&amp;zc=1">
							<?php } else { ?>
	                    <img src="" style="display:none" />
	                    <style>.the-shadow{display:none;}</style>
	                    <?php } ?>
                    	</a>
                    </div> <!-- featured-image -->
			<p class="welcome-par"><?php echo the_content(); ?></p>
			<span class="edits"><?php edit_post_link('Edit this post'); ?> </span> 
<?php endwhile;?>


	<div class="wrapper" style="border:0px solid green;">	


<!--restorative-->	
		<div class="col-inner-services services-full" style="border:0px solid green;">

<div class="service_menu">
			
            <ul class="services-3-column services-overmeyer">
 		  	<?php		  	
		  	$args = array( 'post_type' => 'page', 'category' => 7, 'posts_per_page' => 100, 'order'=> 'ASC', 'orderby' => 'title' );
			$postslist = get_posts( $args );
			foreach ( $postslist as $post ) :
		  	setup_postdata( $post ); ?> 
            <?php 			
			$permalink = get_permalink( $id );			
			?>
			<a href="<?php the_permalink()?>">
			<li class="services_bg_style">
			<a href="<?php the_permalink()?>">
            <div class="services_image">			
            <?php
            if ( has_post_thumbnail() ) { 
			$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
			$imageurl = $thumb['0'];	
			?> <img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo $imageurl; ?>&amp;w=90&amp;h=90&amp;zc=1"> <?php		
			} else {				
			?>
			<img src="<?php bloginfo('template_directory'); ?>/images/no-f-image.jpg"  alt="<?php the_title(); ?>" />
				
			<?php
			}
			?>
			</div> <!-- post-image -->	
           	<div class="black_jack4">
			<a href="<?php the_permalink() ?>"> <div class="services-tittle-links" rel="bookmark" ><?php the_title(); ?></div> </a>
			</div>
			</a>		<!-- post_title_content -->

            </li>    
				
			<?php
			endforeach; 
			wp_reset_postdata();	
			?>                             
			</ul>                            
			</div>
		
		</div>
<!--End Restorative-->


		</div>
	
	

</div><!--wrapper grid2-->

</div><!--end-containerbg-->
</div> <!--end wrap-container-->
<!--welcome home area-->
</div>
</div>

<?php get_footer(); ?>