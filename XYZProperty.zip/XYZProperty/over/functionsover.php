<?php function register_my_menus(){
register_nav_menus( array(
    'primary' => __( 'Primary Menu', 'overmeyer' ),
) );


}
add_action('init', register_my_menus);


// Admin Bar Option
if(get_option('dental_admin_bar') == "Yes") 	{ 
	show_admin_bar(false);
}



// Add category to page 
add_action('admin_init', 'catpage');
function catpage(){
add_meta_box('categorydiv', __('Categories'), 'post_categories_meta_box', 'page', 'side', 'core'); 
register_taxonomy_for_object_type('category', 'page'); 
}

//except the content in blog for words 165 letters
function get_excerpt($count){
  $permalink = get_permalink($post->ID);
  $excerpt = get_the_content();
  $excerpt = strip_tags($excerpt);
  $excerpt = substr($excerpt, 0, $count);
  $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
  $excerpt = $excerpt.'...';
  return $excerpt;
}

// displayfeatured image
if ( function_exists( 'add_theme_support' ) ) { 
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 630, 350, true ); // default Post Thumbnail dimensions (cropped)

// additional image sizes
// delete the next line if you do not need additional image sizes
add_image_size( 'category-thumb', 300, 9999 ); //300 pixels wide (and unlimited height)
}


//register widget Overmeyer Dental Care
register_sidebar(array(
	'name' => __('Overmeyer Dental Care'),
	'id' => 'firsts-right-sidebar',
	'description' => 'Houston Top Dentist 2014',
	'before_widget' => '<div>',
	'after_widget' => '</div>'
	
));
//End register widget Overmeyer Dental Care


// custom post type testimonials
add_action( 'init', 'register_cpt_testimonials' );

function register_cpt_testimonials() {

    $labels = array( 
        'name' => _x( 'Testimonials', 'testimonials' ),
        'singular_name' => _x( 'Testimonials', 'testimonials' ),
        'add_new' => _x( 'Add New', 'testimonials' ),
        'add_new_item' => _x( 'Add New Testimonials', 'testimonials' ),
        'edit_item' => _x( 'Edit Testimonials', 'Testimonials' ),
        'new_item' => _x( 'New Testimonials', 'testimonials' ),
        'view_item' => _x( 'View testimonials', 'testimonials' ),
        'search_items' => _x( 'Search Testimonials', 'testimonials' ),
        'not_found' => _x( 'No testimonials found', 'testimonials' ),
        'not_found_in_trash' => _x( 'No testimonials found in Trash', 'testimonials' ),
        'parent_item_colon' => _x( 'Parent Testimonials:', 'testimonials' ),
        'menu_name' => _x( 'Testimonials', 'testimonials' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'something',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  'page-attributes', 'comments' ),
        'taxonomies' => array('category'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => get_template_directory_uri() ."/images/testimonials.png",
        
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
		 
    );

    register_post_type( 'testimonials', $args );
}
//end custom post type testimonials

// custom post type smilegallery
add_action( 'init', 'register_cpt_smilegallery' );

function register_cpt_smilegallery() {

    $labels = array( 
        'name' => _x( 'Smile Gallery', 'smile gallery' ),
        'singular_name' => _x( 'Smile Gallery', 'smile gallery' ),
        'add_new' => _x( 'Add New', 'smile gallery' ),
        'add_new_item' => _x( 'Add New Smile Gallery', 'smile gallery' ),
        'edit_item' => _x( 'Edit Smile Gallery', 'smile gallery' ),
        'new_item' => _x( 'New Smile Gallery', 'smile gallery' ),
        'view_item' => _x( 'View smile gallery', 'smile gallery' ),
        'search_items' => _x( 'Search Smile Gallery', 'smile gallery' ),
        'not_found' => _x( 'No smile gallery found', 'smile gallery' ),
        'not_found_in_trash' => _x( 'No smile gallery found in Trash', 'smile gallery' ),
        'parent_item_colon' => _x( 'Parent Smile Gallery:', 'smile gallery' ),
        'menu_name' => _x( 'Smile Gallery', 'smile gallery' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'something',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  'page-attributes', 'comments' ),
        'taxonomies' => array('category','post_tag'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => get_template_directory_uri() ."/images/smile.png",
        
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'smilegallery', $args );
	
	
	
}
//End custom post type smilegallery



// custom post type team
add_action( 'init', 'register_cpt_team' );

function register_cpt_team() {

    $labels = array( 
        'name' => _x( 'Team', 'team' ),
        'singular_name' => _x( 'Team', 'team' ),
        'add_new' => _x( 'Add New', 'team' ),
        'add_new_item' => _x( 'Add New Team', 'team' ),
        'edit_item' => _x( 'Edit Team', 'Team' ),
        'new_item' => _x( 'New Team', 'team' ),
        'view_item' => _x( 'View team', 'team' ),
        'search_items' => _x( 'Search Team', 'team' ),
        'not_found' => _x( 'No team found', 'team' ),
        'not_found_in_trash' => _x( 'No team found in Trash', 'team' ),
        'parent_item_colon' => _x( 'Parent Team:', 'team' ),
        'menu_name' => _x( 'Team', 'team' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'something',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  'page-attributes', 'comments' ),
        'taxonomies' => array('category'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => get_template_directory_uri() ."/images/team.png",
        
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
		 
    );

    register_post_type( 'team', $args );
} //end custom post type team




// custom post type for newsletter
add_action( 'init', 'register_cpt_newsletter' );

function register_cpt_newsletter() {

    $labels = array( 
        'name' => _x ('newsletter', 'newsletter' ),
        'singular_name' => _x ('newsletter', 'newsletter' ),
        'add_new' => _x ('Add New', 'newsletter' ),
        'add_new_item' => _x ( 'Add New newsletter', 'newsletter' ),
        'edit_item' => _x ( 'Edit newsletter', 'newsletter' ),
        'new_item' => _x ('New newsletter', 'newsletter' ),
        'view_item' => _x ( 'View newsletter', 'newsletter' ),
        'search_items' => _x ( 'Search newsletter', 'newsletter' ),
        'not_found' => _x ( 'No newsletter found', 'newsletter' ),
        'not_found_in_trash' => _x ( 'No newsletter found in Trash', 'newsletter' ),
        'parent_item_colon' => _x ( 'Parent newsletter:', 'newsletter' ),
        'menu_name' => _x ( 'newsletter', 'newsletter' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'something',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields', 'page-attributes', 'comments' ),
        
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => get_template_directory_uri() ."/images/Newsletter-icon.png",
        
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => false,
        'capability_type' => 'post'
    );

    register_post_type( 'newsletter', $args );
}



// custom post type Offers and Others
add_action( 'init', 'register_cpt_specials' );

function register_cpt_specials() {

    $labels = array( 
        'name' => _x ('Specials', 'specials' ),
        'singular_name' => _x ('Specials', 'specials' ),
        'add_new' => _x ('Add New', 'Specials' ),
        'add_new_item' => _x ( 'Add New Specials', 'specials' ),
        'edit_item' => _x ( 'Edit Specials', 'Specials' ),
        'new_item' => _x ('New Specials', 'specials' ),
        'view_item' => _x ( 'View specials', 'specials' ),
        'search_items' => _x ( 'Search Specials', 'specials' ),
        'not_found' => _x ( 'No Specials found', 'specials' ),
        'not_found_in_trash' => _x ( 'No specials found in Trash', 'specials' ),
        'parent_item_colon' => _x ( 'Parent Specials:', 'specials' ),
        'menu_name' => _x ( 'Specials', 'specials' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'something',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields', 'page-attributes', 'comments' ),
        
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => get_template_directory_uri() ."/images/promo.png",
        
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => false,
        'capability_type' => 'post'
    );

    register_post_type( 'specials', $args );
}




//featured services
register_sidebar(array(
    'name' => __('Featured Services'),
    'id' => 'featured-services',   
    'description' => 'Enter Featured Services',
    'before_widget' => '<div>',
    'after_widget' => '</div>'
)); 




//register widget Footer Links
register_sidebar(array(
	'name' => __('Footer Links'),
	'id' => 'footer-links',
	'description' => 'The Footer Links',
	'before_widget' => '<div>',
	'after_widget' => '</div>'
));



//register widget SIDE BAR SERVICES
register_sidebar(array(
	'name' => __('Sidebar Services Links'),
	'id' => 'side-rights-sidebar',
	'description' => 'The Services bar',
	'before_widget' => '<div>',
	'after_widget' => '</div>'
));

//register widget social icon
register_sidebar(array(
    'name' => __('Footer Widget - Connect With US'),
    'id' => 'connect-with-us',  
    'description' => 'Enter social media links',
    'before_widget' => '<div>',
    'after_widget' => '</div>'
));


//register widget Google Map
register_sidebar(array(
	'name' => __('Overmeyer Dental Care Location'),
	'id' => 'google-map',
	'description' => 'Overmeyer Dental Care Location Of Dental Clinic',
	'before_widget' => '<div>',
	'after_widget' => '</div>'
	
));
//End register widget Overmeyer Dental Care

class socialwidget extends WP_Widget {
    function socialwidget() {
    //Constructor
        $widget_ops = array('classname' => 'widget Information ',  'description' => 'Use this widget for Information Links at the footer');     
        $this->WP_Widget('widget_info', 'SF &raquo; Information ', $widget_ops);
    }
    function widget($args, $instance) {
    // prints the widget
        extract($args, EXTR_SKIP);
        $title = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
        $facebook = empty($instance['facebook']) ? '' : apply_filters('widget_facebook', $instance['facebook']);
        $twitter = empty($instance['twitter']) ? '' : apply_filters('widget_twitter', $instance['twitter']);
        $googleplus = empty($instance['googleplus']) ? '' : apply_filters('widget_googleplus', $instance['googleplus']);
        $linkedin = empty($instance['linkedin']) ? '' : apply_filters('widget_linkedin', $instance['linkedin']);
         ?>
   
    <div class="social-widget">
    <h3 class="foot-tittle" style="font-weight:bold"><?php echo $title; ?> </h3>
       <div class = "icon" >
		<ul>
        <?php if ( $facebook <> "" ) { ?><li><a class="facebook" href="<?php echo $facebook; ?>" target="_blank"></a></li><?php } ?>
        <?php if ( $twitter <> "" ) { ?><li><a class="twitter" href="<?php echo $twitter; ?>" target="_blank"></a></li><?php } ?>
        <?php if ( $googleplus <> "" ) { ?><li><a class="googleplus" href="<?php echo $googleplus; ?>" target="_blank"></a></li><?php } ?>
        <?php if ( $linkedin <> "" ) { ?><li><a class="linkedin" href="<?php echo $linkedin; ?>" target="_blank"></a></li><?php } ?>
        </ul>
      </div>
	 </div>
<?php
    }
    function update($new_instance, $old_instance) {
    //save the widget
        $instance = $old_instance;      
        $instance['title']  = strip_tags($new_instance['title']);
        $instance['facebook']   = ($new_instance['facebook']);
        $instance['twitter']    = ($new_instance['twitter']);
        $instance['googleplus']    = ($new_instance['googleplus']);
        $instance['linkedin']    = ($new_instance['linkedin']);
     
        return $instance;
    }
    function form($instance) {
    //widgetform in backend
        $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'facebook' => '', 'twitter' => '', 'googleplus' => '', 'linkedin' => ''   ) );       
        $title = strip_tags($instance['title']);
        $facebook = ($instance['facebook']);
        $twitter = ($instance['twitter']);
        $googleplus = ($instance['googleplus']);
        $linkedin = ($instance['linkedin']);
         ?>
 <p>
  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" />
  </label>
</p>
 <p>
  <label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook Link:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo attribute_escape($facebook); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter Link:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo attribute_escape($twitter); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('googleplus'); ?>"><?php _e('Google Plus Link:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('googleplus'); ?>" name="<?php echo $this->get_field_name('googleplus'); ?>" type="text" value="<?php echo attribute_escape($googleplus); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('linkedin'); ?>"><?php _e('LinkedIn Link');?>
  <input class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" name="<?php echo $this->get_field_name('linkedin'); ?>" type="text" value="<?php echo attribute_escape($linkedin); ?>" />
  </label>
</p>
<?php
    }}
register_widget('socialwidget');

$themename = "Overmeyer Dental Care";
$shortname = "shortname";
 
$categories = get_categories('hide_empty=0&orderby=name');
$all_cats = array();
foreach ($categories as $category_item ) {
$all_cats[$category_item->cat_ID] = $category_item->cat_name;
}
array_unshift($all_cats, "Select a category");
 
/*---------------------------------------------------
register settings
----------------------------------------------------*/
function theme_settings_init(){
register_setting( 'theme_settings', 'theme_settings' );
wp_enqueue_style("panel_style", get_template_directory_uri()."/panel.css", false, "1.0", "all");
wp_enqueue_script("panel_script", get_template_directory_uri()."/panel_script.js", false, "1.0");
}
 
/*---------------------------------------------------
add settings page to menu
----------------------------------------------------*/
function add_settings_page() {
add_menu_page( __( 'Overmeyer Dental Care' .' Theme Panel' ), __( 'Overmeyer Dental Care' .' Theme Panel' ), 'manage_options', 'settings', 'theme_settings_page');
}
 
/*---------------------------------------------------
add actions
----------------------------------------------------*/
add_action( 'admin_init', 'theme_settings_init' );
add_action( 'admin_menu', 'add_settings_page' );
 
/* ---------------------------------------------------------
Declare options
----------------------------------------------------------- */
 
$theme_options = array (
 
array( "name" => $themename." Options",
"type" => "title"),
 

/* ---------------------------------------------------------
Sizzler Video and Form
----------------------------------------------------------- */
array( "name" => "Sizzler Video and Featured Links",
"type" => "section"),
array( "type" => "open"),
 
array( "name" => "Sizzler Video Link",
"desc" => "Enter the sizzler video Link",
"id" => $shortname."_sizzlervideo",                        
"type" => "text",
"std" => ""),


array( "name" => "I’m Embarrassed to Smile",
"desc" => "Enter I’m Embarrassed to Smile",
"id" => $shortname."_Embarrassedsmile",                        
"type" => "text",
"std" => ""), 

array( "name" => "I’m Embarrassed to Smile",
"desc" => "Enter I I’m Embarrassed to Smile link",
"id" => $shortname."_Embarrassedsmilelink",                        
"type" => "text",
"std" => ""), 


array( "name" => "I Have Pain and Discomfort",
"desc" => "Enter I Have Pain and Discomfort",
"id" => $shortname."_Paindiscomport",                        
"type" => "text",
"std" => ""), 

array( "name" => "I Have Pain and Discomfort",
"desc" => "Enter I Have Pain and Discomfort Link",
"id" => $shortname."_Paindiscomportlink",                        
"type" => "text",
"std" => ""), 


array( "name" => "I Can’t Eat The Food I Love",
"desc" => "Enter I’m I Can’t Eat The Food I Love",
"id" => $shortname."_canteatfood",                        
"type" => "text",
"std" => ""), 

array( "name" => "I Can’t Eat The Food I Love",
"desc" => "Enter I Can’t Eat The Food I Love link",
"id" => $shortname."_canteatfoodlink",                        
"type" => "text",
"std" => ""), 
 
array( "type" => "close"),


/* ---------------------------------------------------------
Address and Phone No.
----------------------------------------------------------- */
array( "name" => "Address and Contact No.",
"type" => "section"),
array( "type" => "open"),

array( "name" => "Logo",
"desc" => "Enter Logo URL",
"id" => $shortname."_logo",                        
"type" => "text",
"std" => ""),
 
array( "name" => "Address",
"desc" => "Enter the complete Address",
"id" => $shortname."_address",                        
"type" => "text",
"std" => ""),


array( "name" => "Contact Number",
"desc" => "Enter Contact Number",
"id" => $shortname."_numero",                        
"type" => "text",
"std" => ""), 

array( "type" => "close"),


);


function wpbeginner_numeric_posts_nav() {

    if( is_singular() )
        return;

    global $wp_query;

    /** Stop execution if there's only 1 page */
    if( $wp_query->max_num_pages <= 1 )
        return;

    $paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
    $max   = intval( $wp_query->max_num_pages );

    /** Add current page to the array */
    if ( $paged >= 1 )
        $links[] = $paged;

    /** Add the pages around the current page to the array */
    if ( $paged >= 3 ) {
        $links[] = $paged - 1;
        $links[] = $paged - 2;
    }

    if ( ( $paged + 2 ) <= $max ) {
        $links[] = $paged + 2;
        $links[] = $paged + 1;
    }

    echo '<div class="navigation"><ul>' . "\n";

    /** Previous Post Link */
    if ( get_previous_posts_link() )
        printf( '<li>%s</li>' . "\n", get_previous_posts_link() );

    /** Link to first page, plus ellipses if necessary */
    if ( ! in_array( 1, $links ) ) {
        $class = 1 == $paged ? ' class="active"' : '';

        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

        if ( ! in_array( 2, $links ) )
            echo '<li>…</li>';
    }

    /** Link to current page, plus 2 pages in either direction if necessary */
    sort( $links );
    foreach ( (array) $links as $link ) {
        $class = $paged == $link ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
    }

    /** Link to last page, plus ellipses if necessary */
    if ( ! in_array( $max, $links ) ) {
        if ( ! in_array( $max - 1, $links ) )
            echo '<li>…</li>' . "\n";

        $class = $paged == $max ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
    }

    /** Next Post Link */
    if ( get_next_posts_link() )
        printf( '<li>%s</li>' . "\n", get_next_posts_link() );

    echo '</ul></div>' . "\n";

}


 
/*---------------------------------------------------
Theme Panel Output
----------------------------------------------------*/
function theme_settings_page() {
    global $themename,$theme_options;
    $i=0;
    $message=''; 
    if ( 'save' == $_REQUEST['action'] ) {
      
        foreach ($theme_options as $value) {
            update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }
      
        foreach ($theme_options as $value) {
            if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
        $message='saved';
    }
    else if( 'reset' == $_REQUEST['action'] ) {
          
        foreach ($theme_options as $value) {
            delete_option( $value['id'] ); }
        $message='reset';        
    }
  
    ?>
    <div class="wrap options_wrap">
        <div id="icon-options-general"></div> 
        <h2 style="color:green;"><img src="<?php echo get_template_directory_uri();?>/images/logo.png"> </h2>
        <?php
        if ( $message=='saved' ) echo '<div class="updated settings-error" id="setting-error-settings_updated"> 
        <p>'.$themename.' settings saved.</strong></p></div>';
        if ( $message=='reset' ) echo '<div class="updated settings-error" id="setting-error-settings_updated"> 
        <p>'.$themename.' settings reset.</strong></p></div>';
        ?>
        <ul>
            <li>Theme version 1.0 </li>
        </ul>
        <div class="content_options">
            <form method="post">
<?php foreach ($theme_options as $value) {
          
                switch ( $value['type'] ) {
              
                    case "open":
					break;
                  
                    case "close": ?>
                    </div>
                    </div><br />
                    <?php break;
                  
                    case "title": ?>
                    <div class="message">
                        <p style="font-style:italic;">To easily use the <?php echo $themename;?> theme options, you can use the options below. Just click the Icon</p>
                    </div>
                    <?php break;
                  
                    case 'text': ?>
                    <div class="option_input option_text">
                    <label for="<?php echo $value['id']; ?>">
                    <?php echo $value['name']; ?></label>
                    <input id="" type="<?php echo $value['type']; ?>" name="<?php echo $value['id']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" />
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case 'textarea': ?>
                    <div class="option_input option_textarea">
                    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
                    <textarea name="<?php echo $value['id']; ?>" rows="" cols=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case 'select': ?>
                    <div class="option_input option_select">
                    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
                    <select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
                    <?php foreach ($value['options'] as $option) { ?>
                            <option <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected"'; } ?>><?php echo $option; ?></option>
                    <?php } ?>
                    </select>
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case "checkbox": ?>
                    <div class="option_input option_checkbox">
                    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
                    <?php if(get_option($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
                    <input id="<?php echo $value['id']; ?>" type="checkbox" name="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> /> 
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case "section": 
                    $i++; ?>
                    <div class="input_section">
                    <div class="input_title">
                         
                        <h3><img src="<?php echo get_template_directory_uri();?>/images/favicon.png" width="30" height="30" alt="">&nbsp;<?php echo $value['name']; ?></h3>
                        <span class="submit"><input name="save<?php echo $i; ?>" type="submit" class="button-primary" value="Save changes" /></span>
                        <div class="clearfix"></div>
                    </div>
                    <div class="all_options">
                    <?php break;
                     
                }
            }?>
          <input type="hidden" name="action" value="save" />
          </form>
          <form method="post">
              <p class="submit">
              <input name="reset" type="submit" value="Reset" />
              <input type="hidden" name="action" value="reset" />
              </p>
          </form>
        </div>
        <div class="footer-admin-credit">
            <p>This theme was made by <a title="sourcefit" href="http://sourcefit.com/" target="_blank" >Sourcefit Inc.</a>.</p>
        </div>
    </div>
    <?php
}

/* ---------------------    THEME PANEL -------------------------------------- */


/*---------------------------------------------------
Office Hours Widget
----------------------------------------------------*/
//register widget Office Hours
register_sidebar(array(
    'name' => __('Office Hours'),
    'id' => 'Office-hours',  
    'description' => 'Office Hours',
    'before_widget' => '<div>',
    'after_widget' => '</div>'
));


// Additing Action hook widgets_init
add_action( 'widgets_init', 'buffercode_widget'); 

function buffercode_widget() {
register_widget( 'buffercode_widget_info' );
}

class buffercode_widget_info extends WP_Widget {

//Name the widget, here Buffercode Widget will be displayed as widget name, $widget_ops may be an array of value, which may holds the title, description like that.

function buffercode_widget_info () {

$this->WP_Widget('buffercode_widget_info', 'OH >> Widget', $widget_ops );        }

//Designing the form widget, which will be displayed in the admin dashboard widget location.

public function form( $instance ) {

if ( isset ($instance[ 'operation' ]) && isset( $instance[ 'name' ]) && isset ($instance[ 'monday' ]) && isset($instance[ 'Tuesday' ])   && isset($instance[ 'Wednesday' ]) 
&& isset($instance[ 'Thursday' ]) && isset($instance[ 'Friday' ]) && isset($instance[ 'Saturday' ]) && isset($instance[ 'Sunday' ])) {
$operation = $instance[ 'operation' ];
$name = $instance[ 'name' ];
$monday = $instance[ 'monday' ];
$Tuesday = $instance[ 'Tuesday' ];
$Wednesday = $instance[ 'Wednesday' ];
$Thursday  = $instance[ 'Thursday' ];
$Friday  = $instance[ 'Friday' ];
$Saturday  = $instance[ 'Saturday' ];

}
else {
$operation = __( '', 'bc_widget_title' );
$name = __( '', 'bc_widget_title' );
$monday = __( '', 'bc_widget_title' );
$Tuesday = __( '', 'bc_widget_title' );
$Wednesday = __( '', 'bc_widget_title' );
$Thursday = __( '', 'bc_widget_title' );
$Friday = __( '', 'bc_widget_title' );
$Saturday = __( '', 'bc_widget_title' );
} ?>
<p>Tittle: <br/> <input name="<?php echo $this->get_field_name( 'name' ); ?>" type="text" value="<?php echo esc_attr( $name );?>" /></p> 
<p>Hours of Operation: <br/> <input name="<?php echo $this->get_field_name( 'operation' ); ?>" type="text" value="<?php echo esc_attr( $operation ); ?>" /></p>
<p>monday: <br/> <input name="<?php echo $this->get_field_name( 'monday' ); ?>" type="text" value="<?php echo esc_attr( $monday ); ?>" /></p>
<p>Tuesday: <br/> <input name="<?php echo $this->get_field_name( 'Tuesday' ); ?>" type="text" value="<?php echo esc_attr( $Tuesday ); ?>" /></p>
<p>Wednesday: <br/> <input name="<?php echo $this->get_field_name( 'Wednesday' ); ?>" type="text" value="<?php echo esc_attr( $Wednesday ); ?>" /></p>
<p>Thursday: <br/> <input name="<?php echo $this->get_field_name( 'Thursday' ); ?>" type="text" value="<?php echo esc_attr( $Thursday ); ?>" /></p>
<p>Friday: <br/> <input name="<?php echo $this->get_field_name( 'Friday' ); ?>" type="text" value="<?php echo esc_attr( $Friday ); ?>" /></p>
<p>Saturday: & Sunday<br/> <input name="<?php echo $this->get_field_name( 'Saturday' ); ?>" type="text" value="<?php echo esc_attr( $Saturday ); ?>" /></p>
<?php } function update($new_instance, $old_instance) {
$instance = $old_instance;

$instance['name'] = ( ! empty( $new_instance['name'] ) ) ? strip_tags( $new_instance['name'] ) : '';

$instance['operation'] = ( ! empty( $new_instance['operation'] ) ) ? strip_tags( $new_instance['operation'] ) : '';

$instance['monday'] = ( ! empty( $new_instance['monday'] ) ) ? strip_tags( $new_instance['monday'] ) : '';

$instance['Tuesday'] = ( ! empty( $new_instance['Tuesday'] ) ) ? strip_tags( $new_instance['Tuesday'] ) : '';

$instance['Wednesday'] = ( ! empty( $new_instance['Wednesday'] ) ) ? strip_tags( $new_instance['Wednesday'] ) : '';

$instance['Thursday'] = ( ! empty( $new_instance['Thursday'] ) ) ? strip_tags( $new_instance['Thursday'] ) : '';

$instance['Friday'] = ( ! empty( $new_instance['Friday'] ) ) ? strip_tags( $new_instance['Friday'] ) : '';

$instance['Saturday'] = ( ! empty( $new_instance['Saturday'] ) ) ? strip_tags( $new_instance['Saturday'] ) : '';

return $instance;

}

//Display the stored widget information in webpage.

function widget($args, $instance) {

extract($args);

echo $before_widget; //Widget starts to print information

$name = apply_filters( 'widget_title', $instance['name'] );

$operation = empty( $instance['operation'] ) ? '&nbsp;' : $instance['operation'];

$monday = empty( $instance['monday'] ) ? '&nbsp;' : $instance['monday'];

$Tuesday = empty( $instance['Tuesday'] ) ? '&nbsp;' : $instance['Tuesday'];

$Wednesday = empty( $instance['Wednesday'] ) ? '&nbsp;' : $instance['Wednesday'];

$Thursday = empty( $instance['Thursday'] ) ? '&nbsp;' : $instance['Thursday'];

$Friday = empty( $instance['Friday'] ) ? '&nbsp;' : $instance['Friday'];

$Saturday = empty( $instance['Saturday'] ) ? '&nbsp;' : $instance['Saturday'];



if ( !empty( $name ) ) { echo $before_title . $name . $after_title; };

$days = array(

 'Monday' => $monday,
 'Tuesday' => $Tuesday,
 'Wednesday' => $Wednesday,
 'Thursday' => $Thursday,
 'Friday' => $Friday,
 'Saturday & Sunday' => $Saturday


);

$str = '<table class="tbl"><tbody><th>Hours of Operation<th> Open &nbsp; &nbsp; &nbsp; Close';
foreach($days as $key=>$day){
 $str .= '<tr class="Business">

 <td class="width"> '.$key.' </td><td>'.attribute_escape($day).'</td>
 </tr>';
}
$str .= '</th></th></tbody></table>';

echo $str;
echo $after_widget; //Widget ends printing information
} }

//pagination in blog


function custom_pagination($numpages = '', $pagerange = '', $paged='') {
 
  if (empty($pagerange)) {
    $pagerange = 2;
  }
 
  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }
 
  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo;'),
    'next_text'       => __('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);
  
  if ($paginate_links) {
    echo "<nav class='custom-pagination paginate'>";
      echo "<span class='page-numbers page-num'>Page " . $paged . " of " . $numpages . "</span> ";
      echo $paginate_links;
    echo "</nav>";
  }
 
}
function ytlink_shortcode($atts) {
	extract(shortcode_atts(array(
	'id' => ''
	), $atts));
	return 'http://www.youtube.com/embed/'.$atts['id'].'?rel=0&amp;autoplay=1&amp;controls=0&amp;showinfo=0&amp;wmode=transparent" frameborder="0" allowfullscreen';
	}
	add_shortcode('ytlink', 'ytlink_shortcode');
	
	
	add_shortcode('ytplayer', array('ytplayer_shortcode', 'shortcode'));
	class ytplayer_shortcode {
    function shortcode($atts, $content=null) {
          extract(shortcode_atts(array(
               'id'      => ''
          ), $atts));
          if (empty($id)) return '<!-- Enter a valid youtube ID -->';
		  return '<a href="http://www.youtube.com/embed/'.$id.'?rel=0&amp;autoplay=1&amp;controls=0&amp;showinfo=0&amp;wmode=transparent"  class="testivid example9">
		  <img src="http://216.135.79.153/lynettecrouse/wp-content/themes/lynettecrouse/timthumb.php?src=http://i1.ytimg.com/vi/'.$id.'/hqdefault.jpg&amp;w=280&amp;h=168&amp;zc=1"
          class="ytplayer-thumb headshot"/>
		<span class="video-short-code-play">
        <img src="http://216.135.79.153/thomasovermeyer/wp-content/themes/overmeyer/images/playvid.png">
		</span>
</a>';
		}
	}

class featured_services_widget extends WP_Widget {
    function featured_services_widget() {
    //Constructor
        $widget_ops = array('classname' => 'widget featured services ',  'description' => 'Use this widget for featured services');     
        $this->WP_Widget('widget_featured_services', 'Renzen &raquo; Featured Services ', $widget_ops);
    }
    function widget($args, $instance) {
    // prints the widget
        extract($args, EXTR_SKIP);
        $servicetitle = empty($instance['servicetitle']) ? '' : apply_filters('widget_servicetitle', $instance['servicetitle']);
        $servicesimageurl = empty($instance['servicesimageurl']) ? '' : apply_filters('widget_servicesimageurl', $instance['servicesimageurl']);
        $servicesdescription = empty($instance['servicesdescription']) ? '' : apply_filters('widget_servicesdescription', $instance['servicesdescription']);
        $serviceslink = empty($instance['serviceslink']) ? '' : apply_filters('widget_serviceslink', $instance['serviceslink']);
         ?>
<div class="col col-services">
            <img src="<?php if ( $servicesimageurl <> "" ) { ?><?php echo $servicesimageurl; ?><?php } ?>" />
            <h3 class="GBservices"><a href="<?php if ( $serviceslink <> "" ) { ?><?php echo $serviceslink; ?><?php } ?>" rel="bookmark"><?php if ( $servicetitle <> "" ) { ?><?php echo $servicetitle; ?><?php } ?></a></h3>
            <p class="services-line"><p class="the-content-service"><?php echo $servicesdescription; ?></p><p>
            <a href="<?php if ( $serviceslink <> "" ) { ?><?php echo $serviceslink; ?><?php } ?>" class="button"><span class="learned">Learn more</span></a> 
            </div>
<?php
    }
    function update($new_instance, $old_instance) {
    //save the widget
        $instance = $old_instance;      
        $instance['servicetitle']   = ($new_instance['servicetitle']);
        $instance['servicesimageurl']    = ($new_instance['servicesimageurl']);
        $instance['servicesdescription']    = ($new_instance['servicesdescription']);
        $instance['serviceslink']    = ($new_instance['serviceslink']);
     
        return $instance;
    }
    function form($instance) {
    //widgetform in backend
        $instance = wp_parse_args( (array) $instance, array( 'servicetitle' => '', 'servicesimageurl' => '', 'servicesdescription' => '', 'serviceslink' => ''   ) );       
        $servicetitle = ($instance['servicetitle']);
        $servicesimageurl = ($instance['servicesimageurl']);
        $servicesdescription = ($instance['servicesdescription']);
        $serviceslink = ($instance['serviceslink']);
         ?>
 <p>
  <label for="<?php echo $this->get_field_id('servicetitle'); ?>"><?php _e('Service Title:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('servicetitle'); ?>" name="<?php echo $this->get_field_name('servicetitle'); ?>" type="text" value="<?php echo attribute_escape($servicetitle); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('servicesimageurl'); ?>"><?php _e('Featured Image:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('servicesimageurl'); ?>" name="<?php echo $this->get_field_name('servicesimageurl'); ?>" type="text" value="<?php echo attribute_escape($servicesimageurl); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('servicesdescription'); ?>"><?php _e('Description:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('servicesdescription'); ?>" name="<?php echo $this->get_field_name('servicesdescription'); ?>" type="text" value="<?php echo attribute_escape($servicesdescription); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('linkserviceslinkedin'); ?>"><?php _e('Service Link');?>
  <input class="widefat" id="<?php echo $this->get_field_id('serviceslink'); ?>" name="<?php echo $this->get_field_name('serviceslink'); ?>" type="text" value="<?php echo attribute_escape($serviceslink); ?>" />
  </label>
</p>
<?php
    }}
register_widget('featured_services_widget');

?>