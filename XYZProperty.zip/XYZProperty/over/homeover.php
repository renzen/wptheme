<?php 
/*
Template Name: Home
*/
get_header(); ?>


<!--banner-->
<div id="wrap-container" class="banner" >
<div id="container" class="contain-bg"> 

<div class="wrapper grid2">
	
		<div class="col col-video">
		<div class="video-holder">
			<div class="video-container">
			 <iframe class="lazy-image" src="http://www.youtube.com/embed/<?php echo get_option("shortname_sizzlervideo");?>?rel=0&amp;showinfo=0&amp;controls=0&amp;wmode=transparent" frameborder="0" width="400" height="350"></iframe>
      </div>
</div>
</div>
	
		<div class="col col-buttons" style="margin-bottom:0px;">
		
       <div class="hcwhy-holder">
	   <div id="hcwhy_title">
	   <h1>How Can We Help You?</h1>
	   </div>
			<div id="hcwhy_button">
					<a href="<?php echo get_option('shortname_Embarrassedsmilelink')?>" class="hcwhy_button_style"><p> <?php echo get_option("shortname_Embarrassedsmile");?></p></a>
                    <a href="<?php echo get_option('shortname_Paindiscomportlink')?>" class="hcwhy_button_style"><p> <?php echo get_option("shortname_Paindiscomport");?></p></a>
                    <a href="<?php echo get_option('shortname_canteatfoodlink')?>" class="hcwhy_button_style"><p> <?php echo get_option("shortname_canteatfood");?></p></a>
                   <a  href="<?php echo home_url('contact-us/make-an-appointment/')?>" class="hcwhy_appointment_button"><span class="maap">MAKE AN APPOINTMENT</span></a>	
            </div>
			</div>
			
		</div>

</div><!--wrapper grid2-->
</div><!--end-containerbg-->
</div> <!--end wrap-container-->
<!--banner-->

<!--Services-->
<div id="wrap-container" class="services-bg" >
<div id="container" class="contain-bg" > 

<div class="wrapper grid4 bs-docs-loading" style="margin:0 auto;text-align:center;margin:70px 0px;">
	
<div class="col">
<div class="featured-wrap ">
<div class="banner-btn"><a href="cosmetic-dentistry"  class="btn-link" >Cosmetic Dentistry</a></div>
<a href="cosmetic-dentistry"  class="featured-image-home" ><img class="lazy-image" src="<?php echo get_template_directory_uri(); ?>/images/services-images.jpg" title="" alt=""></a>

</div> 

</div><!--end col-->
	
		<div class="col">
			<div class="featured-wrap ">
<div class="featured-btn"><a href="teeth-replacement-full-dentures-partial-dentures-mini-and-standard-implants"  class="btn-link" >Teeth Replacement</a></div>
<a href="teeth-replacement-full-dentures-partial-dentures-mini-and-standard-implants"  class="featured-image-home"><img class="lazy-image" src="http://216.135.79.153/thomasovermeyer/wp-content/uploads/sites/60/2014/11/teeth-replacement1.jpg" title="" alt=""></a>
</div> 
		</div><!--end col-->
	
		<div class="col">
			<div class="featured-wrap ">
			<div class="featured-btn"><a href="adult-orthodontics"  class="btn-link" >Adult Orthodontics</a></div>
<a href="adult-orthodontics"  class="featured-image-home" ><img class="lazy-image" src="http://216.135.79.153/thomasovermeyer/wp-content/uploads/sites/60/2014/10/Adult-Orthodontics.jpg" title="" alt=""></a>
</div> 
		</div><!--end col-->
		
		<div class="col">
			<div class="featured-wrap ">
			<div class="featured-btn"><a href="gum-disease-therapy"  class="btn-link" >Gum Disease Therapy</a></div>
<a href="gum-disease-therapy"  class="featured-image-home" ><img class="lazy-image" src="http://216.135.79.153/thomasovermeyer/wp-content/uploads/sites/60/2014/11/services-images.jpg" title="" alt=""></a>
</div> 
		</div><!--end col-->
	
</div>
</div>
</div><!--wrap-container-->
<!--Services-->

<!--welcome home area-->
<div id="wrap-container" class="Welcome-home" >
<div id="container" class="contain-bg"> 

<div class="wrapper grid2">
	
		<div class="col col-welcome-home home-content">
			<h3> Welcome to Overmeyer Family Dental! </h3>	
	<?php
    // query for the about page
    $your_query = new WP_Query( 'pagename=overmeyer-dental-care' );
    // "loop" through query (even though it's just one page) 
    while ( $your_query->have_posts() ) : $your_query->the_post();
		the_post_thumbnail();
        the_content();
    endwhile;
    // reset post data (important!)
    wp_reset_postdata();
	?>
			
		</div>
	
		<div class="col col-ebook">
		<div class="ebook-home-holder">
<div class="ebook-holder home-ebook">
<h2>GET A FREE E-BOOK</h2>
<p style="padding:0px 16px;line-height:17px;"><img src="<?php echo get_template_directory_uri(); ?>/images/ebook.png" class="ebook-image" title="" alt=""> <strong>Avoid These 5 Blunders When 
Choosing a Dentist.</strong> <br>
<span style="line-height:10px;">Fill out the form below and download 
for free our New Report on How to 
Get the Smile You Want in Just an 
Hour. All fieds are required.</span> </p>

<form accept-charset="UTF-8" action="https://smartbox.infusionsoft.com/app/form/process/863ea06ec00df3ab6b6bf1a3fa206a37" class="infusion-form" method="POST">
<input name="inf_form_xid" type="hidden" value="863ea06ec00df3ab6b6bf1a3fa206a37" />
<input name="inf_form_name" type="hidden" value="Overmeyer - Opt-in" />
<input name="infusionsoft_version" type="hidden" value="1.33.0.47" />

<div class="infusion-field">
<input class="infusion-field-input-container ebook-textbox name" id="inf_field_FirstName" name="inf_field_FirstName" placeholder="Your Name" type="text" required/>
</div>

<div class="infusion-field">
<input class="infusion-field-input-container ebook-textbox email" id="inf_field_Email" name="inf_field_Email" placeholder="Enter Email" type="email" required/>
</div>

<div class="infusion-captcha">
<div class="captcha">
<img alt="captcha" border="0px" class="home-captcha" name="captcha" onclick="reloadJcaptcha();" src="https://smartbox.infusionsoft.com/Jcaptcha/img.jsp" title="If you can't read the image, click it to get another one." />
<script type="text/javascript">function reloadJcaptcha() {var now = new Date();if (document.images) {document.images.captcha.src = 'https://smartbox.infusionsoft.com/Jcaptcha/img.jsp?reload=' + now}}</script>
</div>

<div>
<input class="infusion-field-input-container ebook-textbox" id="captcha.typed" name="captcha.typed" placeholder="Enter the above code" type="text" required/>
</div>
</div>
<div class="infusion-submit">
<input type="submit" value="DOWNLOAD NOW" class="submit"/>
</div>
</form> </div>
			
			
		</div>
		
		
		<div style="min-height:200px;border:1px solid red;display:none"> </div>
		
		</div>

</div><!--wrapper grid2-->

</div><!--end-containerbg-->
</div> <!--end wrap-container-->
<!--welcome home area-->

<!--testimonials-->
<div id="wrap-container"> 
<div id="container" style="min-height:50px;margin-bottom:40px;">

<div class="container testimonials-home">
<h3> Patient Testimonials</h3>	
 <p><a href="<?php echo home_url('/patient-testimonials')?>" class="right-readmore">View More</a></p>
<div class="main">
				

				<!-- Elastislide Carousel -->
			
				<!-- End Elastislide Carousel -->

				<ul id="carousel" class="elastislide-list">
							<?php $args = array( 'post_type' => 'testimonials', 'category_name' => 'Patient Testimonials ( Video )', 'posts_per_page' => 100 );?>
                            <?php $loop = new WP_Query( $args ); ?>
                            <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
                            <li>
							<a href="<?php if ( get_post_meta( get_the_ID(), 'video', true ) ) { ?>http://www.youtube.com/embed/<?php echo get_post_meta( get_the_ID(), 'video', true ) ?>?rel=0&amp;autoplay=1&amp;controls=0&amp;showinfo=0&amp;wmode=transparent<?php } ?>"  class="example9 cboxElement gallerypic" title="<?php the_title(); ?>">
                             
                                
							<img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=http://img.youtube.com/vi/<?php echo get_post_meta( get_the_ID(), 'video', true ) ?>/hqdefault.jpg&amp;w=272&amp;h=182&amp;zc=1"  alt="<?php the_title(); ?>" />
							 <span class="zoom-icon">
							 <img alt="Play Now" class="play-png" src="<?php bloginfo('template_directory'); ?>/images/play.png" style="width:100%;"/></span>
								<?php if ( has_post_thumbnail() ) {
                                the_post_thumbnail();
                                } else { ?>
                                <!--img src="<? // bloginfo('template_directory'); ?>/images/no-f-image.jpg" alt="<?php// the_title(); ?>" /-->
                                <?php } ?>
                                </a>
								
                            </li>
                            <?php endwhile; ?>
                        </ul>

			
			</div> 
 
	</div> 
 </div>
</div>
<!--testimonials-->

<!--blog and smile gallery section-->
<div id="wrap-container" class="blog-gallery" >
<div id="container" class="contain-bg"> 
<div class="wrapper grid2 smile-blog">

<div class="box">
		
<div class="col blog">
			<h3> Blog </h3>
			 <p><a href="<?php echo home_url('/blog')?>" class="right-readmore">Read more </a></p>
		
			<div class="blog-home">
			<ul>
                                 <?php
                            $catquery = new WP_Query( 'category_name=blogs&posts_per_page=2' );
                            while($catquery->have_posts()) : $catquery->the_post();
                            ?>
                                <li>
                                
                            <a href="<?php the_permalink()?>">
							<?php if ( has_post_thumbnail() ) {
							$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
							$imageurl = $thumb['0'];
							?>  
							<img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo $imageurl; ?>&amp;w=220&amp;h=150&amp;zc=1">
							<?php } else { ?>
                                <img src="<?php bloginfo('template_directory'); ?>/images/no-f-image.jpg" class="clip-circle" style="float:left" alt="<?php the_title(); ?>" >
                                <?php } ?>
                                </a>
                                <div class="a-title">
                                <a href="<?php the_permalink() ?>" rel="bookmark" class="post_title_content"><?php the_title(); ?></a>
                                <p class="blog-content"><!--?php echo the_content();?--> <?php echo get_excerpt(145);?></p> 
                                <p><a href="<?php the_permalink()?>" class="post-readmore">Read more </a></p>
                                </div> <!-- post_title_content -->
                               
								 
                                </li>
                        <?php endwhile; ?>
						   </ul>
			
			
			</div>
		</div>
	
		<div class="col smile-home">
			<h3> Smile Gallery </h3>
			 <p><a href="<?php echo home_url('/smile-gallery')?>" class="right-readmore">See More</a></p>
			<div class="smile-gallery-home">
			
			<ul>
			
			 <?php $args = array( 'post_type' => 'smilegallery', 'posts_per_page' => 2 );?>
                        <?php $loop = new WP_Query( $args ); ?>
                        <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
                            
							 <li>
							<div id="clip-square">
						    <?php if ( has_post_thumbnail() ) {
							$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
							$imageurl = $thumb['0'];
							?>  
							 <a href="<?php echo $imageurl; ?>" class="hsmilepicz" rel="smilepicz">
							<img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo $imageurl; ?>&amp;w=461&amp;h=186&amp;zc=0">
							</a>
							<?php } else { ?>
                                <img src="<?php bloginfo('template_directory'); ?>/images/no-f-image.jpg" class="clip-circle" style="float:left" alt="<?php the_title(); ?>" >
                                <?php } ?>
							</div> <!-- post-image -->
                            </li>
                        <?php endwhile; ?>
			
			</ul>
			</div>
		</div>
</div>	
</div><!--wrapper grid2-->
</div><!--end-containerbg-->
</div> <!--end wrap-container-->
<!--blog and smile gallery section-->

<?php get_footer(); ?>