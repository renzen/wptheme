<?php 

function register_my_menus(){
register_nav_menus( array(
    'primary' => __( 'Primary Menu', 'rfnavi' ),
) );


}
add_action('init', 'register_my_menus');


// Add category to page 
add_action('admin_init', 'catpage');
function catpage(){
add_meta_box('categorydiv', __('Categories'), 'post_categories_meta_box', 'page', 'side', 'core'); 
register_taxonomy_for_object_type('category', 'page'); 
}

//excerpt the content in blog for words 165 letters
function get_excerpt($count){
  $permalink = get_permalink($post->ID);
  $excerpt = get_the_content();
  $excerpt = strip_tags($excerpt);
  $excerpt = substr($excerpt, 0, $count);
  $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
  $excerpt = $excerpt.'...';
  return $excerpt;
}



//register widget 
register_sidebar(array(
	'name' => __('My Services'),
	'id' => 'services-widget',
	'description' => 'Featured Services',
	'before_widget' => '<div>',
	'after_widget' => '</div>'
	
));
//End register widget 
class featured_services_widget extends WP_Widget {
	function featured_services_widget() {
     $widget_ops = array('classname' => 'widget featured services ',  'description' => 'Use this widget for featured services');     
     $this->WP_Widget('widget_featured_services', 'RF &raquo; Featured Services ', $widget_ops);
    }
function widget($args, $instance) {
		
    // prints the widget
        extract($args, EXTR_SKIP);
        $servicetitle = empty($instance['servicetitle']) ? '' : apply_filters('widget_servicetitle', $instance['servicetitle']);
        $serviceicon = empty($instance['serviceicon']) ? '' : apply_filters('widget_serviceicon', $instance['serviceicon']);
        $servicedescription = empty($instance['servicedescription']) ? '' : apply_filters('widget_servicedescription', $instance['servicedescription']);
         ?>
		
          
				<div class="col-md-4 service-item">
                   <div class="service-icon"><?php echo $serviceicon; ?> </div>
                   <h4 class="service-title"><?php echo $servicetitle; ?></h4>
				    <p class="service-description"><?php echo $servicedescription; ?></p>
				 </div>		
	 
			
			
<?php
    }
    function update($new_instance, $old_instance) {
    //save the widget
        $instance = $old_instance;      
        $instance['servicetitle']   = ($new_instance['servicetitle']);
        $instance['serviceicon']    = ($new_instance['serviceicon']);
        $instance['servicedescription']    = ($new_instance['servicedescription']);
     
        return $instance;
    }
    function form($instance) {
    //widgetform in backend
        $instance = wp_parse_args( (array) $instance, array( 'servicetitle' => '', 'serviceicon' => '', 'servicedescription' => ''   ) );       
        $servicetitle = ($instance['servicetitle']);
        $serviceicon = ($instance['serviceicon']);
        $servicedescription = ($instance['servicedescription']);
         ?>
 <p>
  <label for="<?php echo $this->get_field_id('servicetitle'); ?>"><?php _e('Service Title:');?>
  <input class="widefat" id="<?php echo $this->get_field_id('servicetitle'); ?>" name="<?php echo $this->get_field_name('servicetitle'); ?>" type="text" value="<?php echo attribute_escape($servicetitle); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('serviceicon'); ?>"><?php _e('Featured Icon: (note: just start in wp-content*)');?>
  <input class="widefat" id="<?php echo $this->get_field_id('serviceicon'); ?>" name="<?php echo $this->get_field_name('serviceicon'); ?>" type="text" value="<?php echo attribute_escape($serviceicon); ?>" />
  </label>
</p>
<p>
  <label for="<?php echo $this->get_field_id('linkservicedescriptionedin'); ?>"><?php _e('Service description');?>
  <textarea class="widefat" id="<?php echo $this->get_field_id('servicedescription'); ?>" name="<?php echo $this->get_field_name('servicedescription'); ?>" type="text" value="<?php echo attribute_escape($servicedescription); ?>" /> </textarea>
  </label>
</p>
<?php
    }}
register_widget('featured_services_widget');

// displayfeatured image
if ( function_exists( 'add_theme_support' ) ) { 
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 630, 350, true ); // default Post Thumbnail dimensions (cropped)

// additional image sizes
// delete the next line if you do not need additional image sizes
add_image_size( 'category-thumb', 300, 9999 ); //300 pixels wide (and unlimited height)
}

/* register_post_type */
add_action( 'init', 'register_cpt_services' );
function register_cpt_services() {
		$labels = array( 
        'name' => _x( 'Services', 'services' ),
        'singular_name' => _x( 'Services', 'services' ),
        'add_new' => _x( 'Add New', 'services' ),
        'add_new_item' => _x( 'Add New Services', 'services' ),
        'edit_item' => _x( 'Edit Services', 'Services' ),
        'new_item' => _x( 'New Services', 'services' ),
        'view_item' => _x( 'View Services', 'services' ),
        'search_items' => _x( 'Search Services', 'services' ),
        'not_found' => _x( 'No services found', 'services' ),
        'not_found_in_trash' => _x( 'No services found in Trash', 'services' ),
        'parent_item_colon' => _x( 'Parent Services:', 'services' ),
        'menu_name' => _x( 'Services', 'services' ),
    );
$args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'something',
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields',  'page-attributes', 'comments' ),
        'taxonomies' => array('category'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => get_template_directory_uri() ."/images/favicon.png",
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
		 );
register_post_type( 'services', $args );
}
/* register_post_type */




?>
<?php
/* ---------------------------------- THEME PANEL ---------------*/

/* ----------------------------------------------------------
Declare vars
------------------------------------------------------------- */
$themename = "RF DESIGN";
$shortname = "shortname";
 
$categories = get_categories('hide_empty=0&orderby=name');
$all_cats = array();
foreach ($categories as $category_item ) {
$all_cats[$category_item->cat_ID] = $category_item->cat_name;
}
array_unshift($all_cats, "Select a category");
 
/*---------------------------------------------------
register settings
----------------------------------------------------*/
function theme_settings_init(){
register_setting( 'theme_settings', 'theme_settings' );
wp_enqueue_style("panel_style", get_template_directory_uri()."/panel.css", false, "1.0", "all");
wp_enqueue_script("panel_script", get_template_directory_uri()."/panel_script.js", false, "1.0");
}
 
/*---------------------------------------------------
add settings page to menu
----------------------------------------------------*/
function add_settings_page() {
add_menu_page( __( 'RF DESIGN' .' Theme Panel' ), __( 'RF DESIGN' .' Theme Panel' ), 'manage_options', 'settings', 'theme_settings_page');
}
 
/*---------------------------------------------------
add actions
----------------------------------------------------*/
add_action( 'admin_init', 'theme_settings_init' );
add_action( 'admin_menu', 'add_settings_page' );
 
/* ---------------------------------------------------------
Declare options
----------------------------------------------------------- */
 
$theme_options = array (
 
array( "name" => $themename." Options",
"type" => "title"),
 


/* ---------------------------------------------------------
Banner Section
----------------------------------------------------------- */
array( "name" => "RF Banner Section",
"type" => "section"),
array( "type" => "open"),


array( "name" => "Welcome",
"desc" => "Enter welcome line",
"id" => $shortname."_welcome",                        
"type" => "text",
"std" => ""), 

array( "name" => "About",
"desc" => "Enter about description",
"id" => $shortname."_about",                        
"type" => "text",
"std" => ""), 

array( "name" => "Tagline",
"desc" => "Enter tagline description",
"id" => $shortname."_tagline",                        
"type" => "text",
"std" => ""),

array( "type" => "close"), 
/* ---------------------------------------------------------
Address and Phone No.
----------------------------------------------------------- */
array( "name" => "Address and Contact No. and footer section",
"type" => "section"),
array( "type" => "open"),

 
array( "name" => "Address",
"desc" => "Enter the complete Address here",
"id" => $shortname."_address",                        
"type" => "text",
"std" => ""),


array( "name" => "Contact Number",
"desc" => "Enter Contact Number here",
"id" => $shortname."_numero",                        
"type" => "text",
"std" => ""), 

array( "name" => "Email address",
"desc" => "Enter Email address here",
"id" => $shortname."_emailaddress",                        
"type" => "text",
"std" => ""), 

array( "name" => "Copyright",
"desc" => "Enter Copyright text here",
"id" => $shortname."_copyright",                        
"type" => "text",
"std" => ""), 

array( "type" => "close"),
);
function wpbeginner_numeric_posts_nav() {

    if( is_singular() )
        return;

    global $wp_query;

    /** Stop execution if there's only 1 page */
    if( $wp_query->max_num_pages <= 1 )
        return;

    $paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
    $max   = intval( $wp_query->max_num_pages );

    /** Add current page to the array */
    if ( $paged >= 1 )
        $links[] = $paged;

    /** Add the pages around the current page to the array */
    if ( $paged >= 3 ) {
        $links[] = $paged - 1;
        $links[] = $paged - 2;
    }

    if ( ( $paged + 2 ) <= $max ) {
        $links[] = $paged + 2;
        $links[] = $paged + 1;
    }

    echo '<div class="navigation"><ul>' . "\n";

    /** Previous Post Link */
    if ( get_previous_posts_link() )
        printf( '<li>%s</li>' . "\n", get_previous_posts_link() );

    /** Link to first page, plus ellipses if necessary */
    if ( ! in_array( 1, $links ) ) {
        $class = 1 == $paged ? ' class="active"' : '';

        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

        if ( ! in_array( 2, $links ) )
            echo '<li>…</li>';
    }

    /** Link to current page, plus 2 pages in either direction if necessary */
    sort( $links );
    foreach ( (array) $links as $link ) {
        $class = $paged == $link ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
    }

    /** Link to last page, plus ellipses if necessary */
    if ( ! in_array( $max, $links ) ) {
        if ( ! in_array( $max - 1, $links ) )
            echo '<li>…</li>' . "\n";

        $class = $paged == $max ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
    }

    /** Next Post Link */
    if ( get_next_posts_link() )
        printf( '<li>%s</li>' . "\n", get_next_posts_link() );

    echo '</ul></div>' . "\n";

}function theme_settings_page() {
    global $themename,$theme_options;
    $i=0;
    $message=''; 
    if ( 'save' == $_REQUEST['action'] ) {
      
        foreach ($theme_options as $value) {
            update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }
      
        foreach ($theme_options as $value) {
            if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
        $message='saved';
    }
    else if( 'reset' == $_REQUEST['action'] ) {
          
        foreach ($theme_options as $value) {
            delete_option( $value['id'] ); }
        $message='reset';        
    }
  
    ?>
    <div class="wrap options_wrap">
        <div id="icon-options-general"></div> 
        <h2 style="color:green;"><img src="<?php echo get_template_directory_uri();?>/images/logo.png"> </h2>
        <?php
        if ( $message=='saved' ) echo '<div class="updated settings-error" id="setting-error-settings_updated"> 
        <p>'.$themename.' settings saved.</strong></p></div>';
        if ( $message=='reset' ) echo '<div class="updated settings-error" id="setting-error-settings_updated"> 
        <p>'.$themename.' settings reset.</strong></p></div>';
        ?>
        <ul>
            <li>Theme version 1.0 </li>
        </ul>
        <div class="content_options">
            <form method="post">
  
            <?php foreach ($theme_options as $value) {
          
                switch ( $value['type'] ) {
              
                    case "open": ?>
                    <?php break;
                  
                    case "close": ?>
                    </div>
                    </div><br />
                    <?php break;
                  
                    case "title": ?>
                    <div class="message">
                        <p style="font-style:italic;">To easily use the <?php echo $themename;?> theme options, you can use the options below. Just click the Icon</p>
                    </div>
                    <?php break;
                  
                    case 'text': ?>
                    <div class="option_input option_text">
                    <label for="<?php echo $value['id']; ?>">
                    <?php echo $value['name']; ?></label>
                    <input id="" type="<?php echo $value['type']; ?>" name="<?php echo $value['id']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'])  ); } else { echo $value['std']; } ?>" />
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case 'textarea': ?>
                    <div class="option_input option_textarea">
                    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
                    <textarea name="<?php echo $value['id']; ?>" rows="" cols=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id']) ); } else { echo $value['std']; } ?></textarea>
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case 'select': ?>
                    <div class="option_input option_select">
                    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
                    <select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
                    <?php foreach ($value['options'] as $option) { ?>
                            <option <?php if (get_settings( $value['id'] ) == $option) { echo 'selected="selected"'; } ?>><?php echo $option; ?></option>
                    <?php } ?>
                    </select>
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case "checkbox": ?>
                    <div class="option_input option_checkbox">
                    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
                    <?php if(get_option($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = "";} ?>
                    <input id="<?php echo $value['id']; ?>" type="checkbox" name="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> /> 
                    <small><?php echo $value['desc']; ?></small>
                    <div class="clearfix"></div>
                    </div>
                    <?php break;
                  
                    case "section": 
                    $i++; ?>
                    <div class="input_section">
                    <div class="input_title">
                         
                        <h3><img src="<?php echo get_template_directory_uri();?>/images/favicon.png" width="30" height="30" alt="">&nbsp;<?php echo $value['name']; ?></h3>
                        <span class="submit"><input name="save<?php echo $i; ?>" type="submit" class="button-primary" value="Save changes" /></span>
                        <div class="clearfix"></div>
                    </div>
                    <div class="all_options">
                    <?php break;
                     
                }
            }?>
          <input type="hidden" name="action" value="save" />
          </form>
          <form method="post">
              <p class="submit">
              <input name="reset" type="submit" value="Reset" />
              <input type="hidden" name="action" value="reset" />
              </p>
          </form>
        </div>
        <div class="footer-admin-credit">
            <p>This theme was made by <a title="sourcefit" href="http://renzenflorendo.com/" target="_blank" >Renzen Florendo.</a>.</p>
        </div>
    </div>
    <?php
}

/* ---------------------    THEME PANEL -------------------------------------- */





?>