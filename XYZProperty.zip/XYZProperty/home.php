<?php 
/*
Template Name: Home
*/
get_header(); ?>

  <div id="preloader"></div>

  <!--==========================
  Hero Section
  ============================-->
  <section id="hero">
    <div class="hero-container">
      <div class="wow fadeIn">
        <div class="hero-logo">
          <img class="" src="img/xyz.png" alt="XYZ">
        </div>

        <h1><?php echo get_option('shortname_Welcome')?></h1>
          <h3 class="section-description"><?php echo get_option('shortname_About')?></h3>
        <h2><span class="rotating"><?php echo get_option('shortname_Tagline')?></span></h2>
        <div class="actions">
          
          <a href="#services" class="btn-services">Our Services</a>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Header Section
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#hero"><img src="img/logo.png" alt="" title="" /></a>
       
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#hero">Home</a></li>
          <li><a href="#services">Services</a></li>   
          <li><a href="#pricing">Pricing Table</a></li> 
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </nav>
      <!-- #nav-menu-container -->
    </div>
  </header>
  <!-- #header -->

  

  <!--==========================
  Services Section
  ============================-->
  <section id="services">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">Our Services</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</p>
        </div>
      </div>

      <div class="row">

	  
	<div class="tea">  <?php dynamic_sidebar('services-widget');?> </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-desktop"></i></div>
          <h4 class="service-title"><a href="">Property Assessment</a></h4>
          <p class="service-description">Before we even list your home, we’ll do a thorough assessment and recommend any necessary repairs that will bring your property up to code and make it more appealing to the best tenants. We know the San Francisco legal requirements and we understand the needs of the local tenant pool. Our initial assessment will help you rent your property faster and for the most money.</p>
        </div>
       
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-paper-plane"></i></div>
          <h4 class="service-title"><a href="">Listing and Marketing</a></h4>
          <p class="service-description">Our marketing is targeted and effective. We use online advertising, our own website, and our
connections within the San Francisco community to attract potential tenants. We’re available for
showings and prepared to answer any questions prospective renters have about your property.
</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-photo"></i></div>
          <h4 class="service-title"><a href="">Tenant Screening</a></h4>
          <p class="service-description">The tenant you place has a direct impact on your success as a landlord. We believe in placing good tenants with a proven record of on-time rental payments. We screen for credit, criminal, and eviction backgrounds, and talk to former landlords to ensure we only hand over the keys to tenants who follow the terms of the lease and take good care of a home.</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-road"></i></div>
          <h4 class="service-title"><a href="">Lease Preparation</a></h4>
          <p class="service-description">Your lease needs to be specific to California, legally enforceable, and detailed. All of our rental
agreements are up to date and compliant with local, state, and federal laws. It’s written to protect you and your property, while outlining the expectations and responsibilities of your tenant.
</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-shopping-bag"></i></div>
          <h4 class="service-title"><a href="">Financial Reporting</a></h4>
          <p class="service-description">Expect monthly owner statements that are accurate, detailed, and transparent. You’ll see all of the income and expenses associated with your property, and you’ll be able to access this information any time you need it. At the end of the year, we’ll provide 1099s for easy tax reporting.</p>
        </div>

      
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-paper-plane"></i></div>
          <h4 class="service-title"><a href="">Eviction Coverage</a></h4>
          <p class="service-description">When XYZ Property Management is responsible for placing your tenants, evictions are rare. But, bad things happen to good tenants, and we may find ourselves in the position that we have to evict for nonpayment of rent or due to some violation of the lease. In these cases, we’ll work closely with an experienced attorney to make sure the eviction is handled professionally, correctly, and in as little time as possible.
</p>
        </div>

      </div>
    </div>
  </section>

  <!--==========================
  Subscrbe Section
  ============================-->
  <section id="pricing">
    <div class="container wow fadeInUp">
      <div class="row">

<div class="row">
        <div class="col-md-12">
        <?php dynamic_sidebar('table-widget');?></div>
          <h3 class="section-title">CHOOSE THE BEST PRICE FOR YOU</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">Professional property management is never going to be one-size- fits-all. That’s why we have three different pricing plans so you can choose the services that fit your budget. 

Our pricing is transparent. There won’t be any surprise fees or hidden charges.  

We know we offer our owners and investors services and expertise they can’t find elsewhere. When you’re wondering if you can afford to work with us, the question you should really be asking is – can you afford NOT to?</p>
        </div>
      </div>


        <table border="1" width="624" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="133">
</td>
<td width="178">
</td>
<td width="104">
<p><strong>Tier 1</strong></p>
</td>
<td width="104">
<p><strong>Tier 2</strong></p>
</td>
<td width="104">
<p><strong>Tier 3</strong></p>
</td>
</tr>
<tr>
<td width="133">
</td>
<td width="178">
</td>
<td width="104">
<p><strong>Leasing Only Service</strong></p>
</td>
<td width="104">
<p><strong>Full Service Management</strong></p>
</td>
<td width="104">
<p><strong>Gold Standard</strong></p>
</td>
</tr>
<tr>
<td colspan="2" width="311">
<p><strong>Leasing Fee</strong></p>
</td>
<td width="104">
<p><em>70% of 1 Month's Rent</em></p>
</td>
<td width="104">
<p><em>50% of 1 Month's Rent</em></p>
</td>
<td width="104">
<p><em>50% of 1 Month's Rent</em></p>
</td>
</tr>
<tr>
<td colspan="2" width="311">
<p><strong>Monthly Management Fee</strong></p>
</td>
<td width="104">
<p><em>No Monthly Fees</em></p>
</td>
<td width="104">
<p><em>7% Monthly Management Fee</em></p>
</td>
<td width="104">
<p><em>9% Monthly Management Fee</em></p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Main Service Description (Displayed)</strong></p>
</td>
<td width="178">
<p><strong>Sub-services Description (Show only on mouse hover)</strong></p>
</td>
<td width="104">
</td>
<td width="104">
</td>
<td width="104">
</td>
</tr>
<tr>
<td width="133">
<p><strong>Rental Analysis</strong></p>
</td>
<td width="178">
<p>We look at different factors to give you the best rental price for your property</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Listing &amp; Marketing</strong></p>
</td>
<td width="178">
<p>We market your property to tenants and handle all the inquiries and showings</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Tenant Screening &amp; Placement</strong></p>
</td>
<td width="178">
<p>Credit and eviction background screening</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Lease Preparation</strong></p>
</td>
<td width="178">
<p>We'll prepare a strong lease that will protect you as a landlord</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Financial Reporting</strong></p>
</td>
<td width="178">
<p>Year-end Statement &amp; 1099</p>
</td>
<td width="104">
<p><strong>X</strong></p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Rent Collection</strong></p>
</td>
<td width="178">
<p>Includes dealing with tenants who don't pay on time or who do not pay at all.</p>
</td>
<td width="104">
<p><strong>X</strong></p>
</td>
<td width="104">
<p>✔</p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Accounting</strong></p>
</td>
<td width="178">
<p>Detailed monthly owner statements so you can stay on top of your cashflow</p>
</td>
<td width="104">
<p><strong>X</strong></p>
</td>
<td width="104">
<p><strong>X</strong></p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
<tr>
<td width="133">
<p><strong>Move-out Inspections</strong></p>
</td>
<td width="178">
<p>Detailed inspection with photos</p>
</td>
<td width="104">
<p><strong>X</strong></p>
</td>
<td width="104">
<p><strong>X</strong></p>
</td>
<td width="104">
<p>✔</p>
</td>
</tr>
</tbody>
</table>
      </div>
    </div>
  </section>

 



  <!--==========================
  Contact Section
  ============================-->
  <section id="contact">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">Contact Us</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
        </div>
      </div>

      <div class="row">
        <div class="col-md-3 col-md-push-2">
          <div class="info">
            <div>
              <i class="fa fa-map-marker"></i>
              <p>123 Main St.<br>San Francisco, CA 10001</p>
            </div>



            <div>
              <i class="fa fa-envelope"></i>
              <p>info@example.com</p>
            </div>

            <div>
              <i class="fa fa-phone"></i>
              <p>(415) 123-4567</p>
            </div>

          </div>
        </div>

        <div class="col-md-5 col-md-push-2">
          <div class="form">
            <div id="sendmessage">Your message has been sent. Thank you!</div>
            <div id="errormessage"></div>
            <form action="" method="post" role="form" class="contactForm">
              <div class="form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validation"></div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php get_footer(); ?>