
  <!--==========================
  Footer
============================-->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
            <div class="social" style="text-align:center">
              <a href=""><i class="icon-circled fa fa-twitter fa-2x"></i></a>
              <a href=""><i class="icon-circled fa fa-facebook fa-2x"></i></a>
              <a href=""><i class="icon-circled fa fa-google-plus fa-2x"></i></a>
              <a href=""><i class="icon-circled fa fa-linkedin fa-2x"></i></a>
            </div>
          <div class="copyright">
		  <?php echo get_option('shortname_copyright')?>
            
          </div>
          
        </div>
      </div>
    </div>
  </footer>
  <!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Required JavaScript Libraries -->
  <script src="<?php echo get_template_directory_uri();?>/js/jquery.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/hoverIntent.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/superfish.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/morphext.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/wow.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/sticky.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/js/easing.js"></script>

  <!-- Template Specisifc Custom Javascript File -->
  <script src="<?php echo get_template_directory_uri();?>/js/custom.js"></script>

  <script src="<?php echo get_template_directory_uri();?>/js/contactform.js"></script>

  <?php wp_footer(); ?>
</body>

</html>
